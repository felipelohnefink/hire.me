/*
create table link
(
  id integer not null,
  url varchar(255) not null,
  alias varchar(255),
  primary key (id)
);
*/

INSERT INTO LINK (ID, URL, ALIAS)
VALUES (10001, 'http://tolkiengateway.net', 'tolkien');
INSERT INTO LINK (ID, URL, ALIAS)
VALUES (10002, 'http://www.google.com', 'google');
INSERT INTO LINK (ID, URL, ALIAS)
VALUES (10003, 'http://www.facebook.com', 'facebook');