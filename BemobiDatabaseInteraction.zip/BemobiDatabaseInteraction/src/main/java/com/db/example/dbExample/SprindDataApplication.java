package com.db.example.dbExample;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.db.example.dbExample.entity.Link;
import com.db.example.dbExample.springdata.LinkSpringDataRepository;

@SpringBootApplication
public class SprindDataApplication implements CommandLineRunner {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	LinkSpringDataRepository repository;
	
	public static void main(String[] args) {
		SpringApplication.run(SprindDataApplication.class, args);
	}

	@Override
	public void run(String... arg0) throws Exception {
 		logger.info("\nAll saved links -> {}", repository.findAll());
		logger.info("\nLink with Id 10002 -> {}", repository.findOne(10002));
 		logger.info("\nInserting Link... Rows inserted -> {}", repository.save(new Link(10004, "http://www.pinterest.com", "pint")));
 		logger.info("\nUpdating Link with id 10002... Rows updated -> {}", repository.save(new Link(10002, "http://www.github.com", "github")));
 		repository.delete(10003);
 		logger.info("\nAll saved links -> {}", repository.findAll());
 		/*
 		logger.info("\nLink with Alias tolkien -> {}", dao.findByAlias("tolkien"));
 		*/
	}
}
