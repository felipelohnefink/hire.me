package com.db.example.dbExample;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;

import com.db.example.dbExample.entity.Link;
import com.db.example.dbExample.jpa.LinkJpaRepository;

//@SpringBootApplication
public class JpaApplication implements CommandLineRunner {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	LinkJpaRepository repository;
	
	public static void main(String[] args) {
		SpringApplication.run(JpaApplication.class, args);
	}

	@Override
	public void run(String... arg0) throws Exception {
 		logger.info("\nAll saved links -> {}", repository.findAll());
		logger.info("\nLink with Id 10002 -> {}", repository.findById(10002));
 		logger.info("\nInserting Link... Rows inserted -> {}", repository.insert(new Link(10004, "http://www.pinterest.com", "pint")));
 		logger.info("\nUpdating Link with id 10002... Rows updated -> {}", repository.update(new Link(10002, "http://www.github.com", "github")));
 		repository.deleteById(10003);
 		logger.info("\nAll saved links -> {}", repository.findAll());
 		/*
 		logger.info("\nLink with Alias tolkien -> {}", dao.findByAlias("tolkien"));
 		*/
	}
}
