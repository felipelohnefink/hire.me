package com.db.example.dbExample.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name="find_all_links", query="select l from Link l")
public class Link {
	
	@Id
	@GeneratedValue
	private int id;
	
	private String url;
	private String alias;
	
	public Link() {
		
	}
	
	public Link(String url, String alias) {
		super();
		this.url = url;
		this.alias = alias;
	}
	
	public Link(int id, String url, String alias) {
		super();
		this.id = id;
		this.url = url;
		this.alias = alias;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	@Override
	public String toString() {
		return "\nLink [id=" + id + ", url=" + url + ", alias=" + alias + "]";
	}
}
