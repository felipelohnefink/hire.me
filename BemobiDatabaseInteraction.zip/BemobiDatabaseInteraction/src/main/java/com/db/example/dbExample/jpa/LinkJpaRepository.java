package com.db.example.dbExample.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.db.example.dbExample.entity.Link;

@Repository
@Transactional
public class LinkJpaRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	public List<Link> findAll() {
		TypedQuery<Link> namedQuery = entityManager.createNamedQuery("find_all_links", Link.class);
		return namedQuery.getResultList();
	}
	
	public Link findById(int id) {
		return entityManager.find(Link.class, id);
	}
	
	public Link update(Link link) {
		return entityManager.merge(link);
	}
	
	public Link insert(Link link) {
		return entityManager.merge(link);
	}
	
	public void deleteById(int id) {
		Link link = findById(id);
		entityManager.remove(link);
	}
}
