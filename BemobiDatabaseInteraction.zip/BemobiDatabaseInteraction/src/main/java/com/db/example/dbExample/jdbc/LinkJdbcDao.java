package com.db.example.dbExample.jdbc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.db.example.dbExample.entity.Link;

@Repository
public class LinkJdbcDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public List<Link> findAll() {
		return jdbcTemplate.query("select * from link", new BeanPropertyRowMapper(Link.class));
	}
	
	public Link findById(int id) {
		return jdbcTemplate.queryForObject("select * from link where id=?", new Object[]{id} ,new BeanPropertyRowMapper(Link.class));
	}
	
	public Link findByAlias(String alias) {
		return jdbcTemplate.queryForObject("select * from link where alias=?", new Object[]{alias} ,new BeanPropertyRowMapper(Link.class));
	}
	
	public int deleteById(int id) {
		return jdbcTemplate.update("delete from link where id=?", new Object[]{id});
	}
	
	public int insert(Link link) {
		return jdbcTemplate.update("insert into link (id, url, alias) values (?, ?, ?)",
		    new Object[] {link.getId(), link.getUrl(), link.getAlias()});
	}
	
	public int update(Link link) {
		return jdbcTemplate.update("update link set url = ?, alias = ? where id = ?",
		    new Object[] {link.getUrl(), link.getAlias(), link.getId()});
	}
}
