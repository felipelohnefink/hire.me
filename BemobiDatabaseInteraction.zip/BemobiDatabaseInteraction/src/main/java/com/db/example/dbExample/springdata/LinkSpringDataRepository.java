package com.db.example.dbExample.springdata;

import org.springframework.data.jpa.repository.JpaRepository;

import com.db.example.dbExample.entity.Link;

public interface LinkSpringDataRepository extends JpaRepository<Link, Integer>{

}
