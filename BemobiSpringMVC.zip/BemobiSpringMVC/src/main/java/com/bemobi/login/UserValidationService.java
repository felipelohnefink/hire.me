package com.bemobi.login;

import org.springframework.stereotype.Service;

@Service
public class UserValidationService {

	public boolean isUserValid(String user, String password) {
		if(user.equals("asd") && password.equals("123"))
			return true;
		
		return false;
	}
}
