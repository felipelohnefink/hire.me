package unique;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ShortEntryController {

    @PostMapping("/link")
    public ResponseEntity<?> save(@RequestBody ShortEntry se){
    	return ResponseEntity.ok().body("New Link has been saved with new ID!");// + id);
    }
}