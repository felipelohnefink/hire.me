package unique;

import java.util.List;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "links", path = "links")
public interface ShortEntryRepository extends PagingAndSortingRepository<ShortEntry, Long> {
	List<ShortEntry> findByAlias(@Param("alias") String alias);
}